// Пользователи, пароли, вход и выход.
// Сессия хранится в cookie «sid» (недоступна JavaScript-коду страницы),
// в базе лежит только хеш токена.
import { createHash, randomBytes, randomInt, randomUUID, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { config } from './config.js';
import { db, sessions, users } from './db.js';
import { AppError } from './errors.js';

const scrypt = promisify(scryptCb);
export const COOKIE = 'sid';
const MIN_PASSWORD = 8;

// ---------- Пароли ----------

export async function hashPassword(password) {
  const salt = randomBytes(16);
  const key = await scrypt(password, salt, 64);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

async function verifyPassword(password, stored) {
  const [alg, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt' || !salt || !hash) return false;
  const expected = Buffer.from(hash, 'base64');
  if (expected.length !== 64) return false;
  const key = await scrypt(password, Buffer.from(salt, 'base64'), expected.length);
  return timingSafeEqual(key, expected);
}

// Пароль без похожих символов (0/O, 1/l), удобно продиктовать.
export function generatePassword(length = 10) {
  const alphabet = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length }, () => alphabet[randomInt(alphabet.length)]).join('');
}

export function checkPassword(password) {
  if (typeof password !== 'string' || password.length < MIN_PASSWORD) throw new AppError('WEAK_PASSWORD', 400);
  return password;
}

// ---------- Пользователи ----------

const normLogin = (login) => String(login ?? '').trim().toLowerCase();

export function parseLogin(login) {
  const value = normLogin(login);
  if (!/^[a-z0-9._@-]{3,40}$/.test(value)) {
    throw new AppError('BAD_REQUEST', 400, 'login: 3–40 символов, латиница, цифры, точка, дефис, @');
  }
  return value;
}

const startOfTodayUtc = () => new Date().toISOString().slice(0, 10);

// Сколько генераций пользователь сделал сегодня. Неудачные не считаются:
// за них сервис возвращает кредиты.
export function usedToday(userId) {
  const today = startOfTodayUtc();
  return db.filter((m) => m.userId === userId && m.status !== 'failed' && m.createdAt.slice(0, 10) === today).length;
}

// Лимит пользователя: свой, если задан, иначе общий. 0 — без лимита.
export const limitOf = (user) => user.dailyLimit ?? (user.role === 'admin' ? 0 : config.dailyLimit);

export function assertWithinLimit(user) {
  const limit = limitOf(user);
  if (limit > 0 && usedToday(user.id) >= limit) throw new AppError('LIMIT_REACHED', 429, `Лимит: ${limit} в день`);
}

export function publicUser(user) {
  const limit = limitOf(user);
  const used = usedToday(user.id);
  return {
    id: user.id,
    login: user.login,
    name: user.name,
    role: user.role,
    disabled: Boolean(user.disabled),
    dailyLimit: limit,
    usedToday: used,
    remainingToday: limit > 0 ? Math.max(0, limit - used) : null,
    createdAt: user.createdAt,
  };
}

export async function createUser({ login, name, password, role = 'user', dailyLimit = null }) {
  const value = parseLogin(login);
  if (users.find((u) => u.login === value)) throw new AppError('LOGIN_TAKEN', 409);
  if (!['user', 'admin'].includes(role)) throw new AppError('BAD_REQUEST', 400, 'role: user или admin');
  const now = new Date().toISOString();
  return users.insert({
    id: randomUUID(),
    login: value,
    name: String(name || value).trim().slice(0, 60),
    role,
    dailyLimit,
    disabled: false,
    passwordHash: await hashPassword(checkPassword(password)),
    createdAt: now,
    updatedAt: now,
  });
}

// Модели, созданные до появления аккаунтов, отдаём первому администратору.
async function adoptOrphanModels() {
  const admin = users.find((u) => u.role === 'admin');
  if (!admin) return;
  const orphans = db.filter((m) => !m.userId);
  for (const m of orphans) await db.update(m.id, { userId: admin.id });
  if (orphans.length) console.log(`Модели без владельца (${orphans.length}) переданы администратору «${admin.login}».`);
}

// Первый администратор из .env, если пользователей ещё нет.
export async function ensureAdmin() {
  await createFirstAdmin();
  await adoptOrphanModels();
}

async function createFirstAdmin() {
  if (users.all().length) return;
  if (!config.adminLogin || !config.adminPassword) {
    console.warn('! Пользователей нет. Укажите ADMIN_LOGIN и ADMIN_PASSWORD в .env и перезапустите сервер.');
    return;
  }
  await createUser({ login: config.adminLogin, password: config.adminPassword, role: 'admin', name: 'Администратор' });
  console.log(`Создан администратор «${config.adminLogin}». Пароль из .env можно теперь убрать.`);
}

// ---------- Защита от подбора пароля ----------

const attempts = new Map(); // ключ → { count, until }
const MAX_ATTEMPTS = 5;
const LOCK_MS = 15 * 60_000;

function checkAttempts(keys) {
  const now = Date.now();
  for (const key of keys) {
    const a = attempts.get(key);
    if (a?.until > now) throw new AppError('TOO_MANY_ATTEMPTS', 429);
  }
}

// Неудачные попытки считаются в окне 15 минут; после лимита — блок на 15 минут.
function registerFailure(keys) {
  const now = Date.now();
  for (const [key, limit] of keys) {
    const a = attempts.get(key);
    const fresh = !a || now - a.first > LOCK_MS;
    const count = fresh ? 1 : a.count + 1;
    attempts.set(key, { first: fresh ? now : a.first, count, until: count >= limit ? now + LOCK_MS : 0 });
  }
}

function cleanupAttempts() {
  const now = Date.now();
  for (const [key, a] of attempts) {
    if (now - a.first > LOCK_MS && a.until <= now) attempts.delete(key);
  }
}

// ---------- Сессии ----------

const hashToken = (token) => createHash('sha256').update(token).digest('hex');

export async function login(req, res, loginValue, password) {
  const value = normLogin(loginValue);
  const keys = [
    [`login:${value}`, MAX_ATTEMPTS],
    [`ip:${req.ip}`, MAX_ATTEMPTS * 4],
  ];
  checkAttempts(keys.map(([k]) => k));

  const user = users.find((u) => u.login === value);
  const ok = user && !user.disabled && (await verifyPassword(String(password ?? ''), user.passwordHash));
  if (!ok) {
    registerFailure(keys);
    throw new AppError('LOGIN_FAILED', 401);
  }
  for (const [key] of keys) attempts.delete(key);

  const token = randomBytes(32).toString('base64url');
  const maxAge = config.sessionDays * 24 * 60 * 60 * 1000;
  await sessions.insert({
    id: randomUUID(),
    tokenHash: hashToken(token),
    userId: user.id,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + maxAge).toISOString(),
  });
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge, path: '/' });
  return { user, token };
}

function readCookie(req) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === COOKIE) return decodeURIComponent(v.join('='));
  }
  return null;
}

// Токен входа: из заголовка «Authorization: Bearer …» (фронтенд на другом
// адресе, например на Vercel) или из cookie (страницы самого сервера).
function readToken(req) {
  const header = req.headers.authorization || '';
  const match = /^Bearer\s+(\S+)$/i.exec(header);
  return match ? match[1] : readCookie(req);
}

export async function logout(req, res) {
  const token = readToken(req);
  if (token) {
    const hash = hashToken(token);
    await sessions.removeWhere((s) => s.tokenHash === hash);
  }
  res.clearCookie(COOKIE, { path: '/' });
}

// Выйти на всех устройствах (например, после смены пароля).
export const dropSessions = (userId) => sessions.removeWhere((s) => s.userId === userId);

export async function cleanupSessions() {
  cleanupAttempts();
  const now = new Date().toISOString();
  await sessions.removeWhere((s) => s.expiresAt < now);
}

export { verifyPassword };

// ---------- Middleware ----------

// Находит пользователя по cookie и кладёт его в req.user.
export function authenticate(req, _res, next) {
  const token = readToken(req);
  if (token) {
    const hash = hashToken(token);
    const now = new Date().toISOString();
    const session = sessions.find((s) => s.tokenHash === hash && s.expiresAt > now);
    const user = session && users.get(session.userId);
    if (user && !user.disabled) req.user = user;
  }
  next();
}

export function requireUser(req, _res, next) {
  next(req.user ? undefined : new AppError('UNAUTHORIZED', 401));
}

export function requireAdmin(req, _res, next) {
  if (!req.user) return next(new AppError('UNAUTHORIZED', 401));
  next(req.user.role === 'admin' ? undefined : new AppError('FORBIDDEN', 403));
}
