@echo off
rem Запускает сервер. Окно не закрывайте, пока сервер нужен.
chcp 65001 >nul
cd /d "%~dp0"
title Sketch3D server
"D:\Programs\nodejs\node.exe" --env-file-if-exists=.env src/server.js
pause
