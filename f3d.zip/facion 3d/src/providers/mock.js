// Тестовый режим: ничего не отправляет наружу и не тратит кредиты.
// «Генерация» длится MOCK_DURATION_SEC секунд и возвращает модель платья.
// Если в имени загруженного файла есть слово «fail», задание завершится ошибкой —
// так фронтендер может проверить экран ошибки.
import fs from 'node:fs/promises';
import { config } from '../config.js';
import { errorInfo } from '../errors.js';
import { buildMockDressGlb } from './mock-glb.js';

const QUEUE_MS = 3000;

export const mock = {
  id: 'mock',
  name: 'Тестовый режим',
  acceptedFormats: ['jpeg', 'png', 'webp'],
  configured: () => true,

  async createTask({ hints = {} }) {
    // Вся информация о задании зашита в его номер, поэтому
    // перезапуск сервера ничего не ломает.
    return `mock_${Date.now()}_${hints.fail ? 'fail' : 'ok'}`;
  },

  async getTask(taskId) {
    const [, startedAt, outcome] = taskId.split('_');
    const elapsed = Date.now() - Number(startedAt);
    const total = config.mock.durationSec * 1000;

    if (elapsed < QUEUE_MS) return { status: 'queued', progress: 0 };
    if (elapsed < total) {
      const progress = Math.min(99, Math.round(((elapsed - QUEUE_MS) / (total - QUEUE_MS)) * 100));
      return { status: 'running', progress };
    }
    if (outcome === 'fail') {
      return { status: 'failed', progress: 0, error: errorInfo('GENERATION_FAILED', 'Тестовая ошибка (в имени файла есть «fail»)') };
    }
    return { status: 'success', progress: 100, credits: 0 };
  },

  // Вместо скачивания: строим модель сами, превью — копия эскиза.
  async saveResult(_task, { modelPath, previewPath, sketchPath }) {
    await fs.writeFile(modelPath, buildMockDressGlb());
    await fs.copyFile(sketchPath, previewPath);
  },

  async getBalance() {
    return { balance: 9999, frozen: 0 };
  },
};
