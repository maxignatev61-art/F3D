// Строит простую 3D-модель платья (GLB) без внешних библиотек.
// Нужна только для тестового режима.

// Профиль платья сверху вниз: [радиус, высота] в метрах.
const PROFILE = [
  [0.07, 1.42], // горловина
  [0.16, 1.40], // плечи
  [0.18, 1.33],
  [0.19, 1.22], // грудь
  [0.16, 1.10],
  [0.14, 1.02], // талия
  [0.18, 0.92],
  [0.24, 0.80], // бёдра
  [0.31, 0.60],
  [0.38, 0.40],
  [0.44, 0.22], // подол
];
const SEGMENTS = 48;

function buildLathe() {
  const positions = [];
  const normals = [];
  const indices = [];
  const rows = PROFILE.length;

  for (let i = 0; i < rows; i++) {
    // Касательная к профилю → нормаль, смотрящая наружу.
    const prev = PROFILE[Math.max(i - 1, 0)];
    const next = PROFILE[Math.min(i + 1, rows - 1)];
    const dr = next[0] - prev[0];
    const dy = next[1] - prev[1];
    const len = Math.hypot(dr, dy) || 1;
    const nr = -dy / len;
    const ny = dr / len;
    const [r, y] = PROFILE[i];

    for (let j = 0; j <= SEGMENTS; j++) {
      const a = (j / SEGMENTS) * Math.PI * 2;
      const cos = Math.cos(a);
      const sin = Math.sin(a);
      positions.push(r * cos, y, r * sin);
      normals.push(nr * cos, ny, nr * sin);
    }
  }

  const stride = SEGMENTS + 1;
  for (let i = 0; i < rows - 1; i++) {
    for (let j = 0; j < SEGMENTS; j++) {
      const a = i * stride + j;
      const b = a + stride;
      const c = a + 1;
      const d = b + 1;
      indices.push(a, c, b, c, d, b);
    }
  }
  return { positions, normals, indices };
}

const pad4 = (n) => (n + 3) & ~3;

export function buildMockDressGlb() {
  const { positions, normals, indices } = buildLathe();
  const pos = new Float32Array(positions);
  const nor = new Float32Array(normals);
  const idx = new Uint16Array(indices);

  const posBytes = pos.byteLength;
  const norBytes = nor.byteLength;
  const idxBytes = idx.byteLength;
  const binLength = pad4(posBytes + norBytes + idxBytes);

  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < pos.length; i += 3) {
    for (let k = 0; k < 3; k++) {
      min[k] = Math.min(min[k], pos[i + k]);
      max[k] = Math.max(max[k], pos[i + k]);
    }
  }

  const gltf = {
    asset: { version: '2.0', generator: 'sketch-to-3d mock' },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0, name: 'MockDress' }],
    meshes: [{ primitives: [{ attributes: { POSITION: 0, NORMAL: 1 }, indices: 2, material: 0 }] }],
    materials: [
      {
        name: 'Fabric',
        doubleSided: true,
        pbrMetallicRoughness: { baseColorFactor: [0.78, 0.45, 0.52, 1], metallicFactor: 0, roughnessFactor: 0.85 },
      },
    ],
    buffers: [{ byteLength: binLength }],
    bufferViews: [
      { buffer: 0, byteOffset: 0, byteLength: posBytes, target: 34962 },
      { buffer: 0, byteOffset: posBytes, byteLength: norBytes, target: 34962 },
      { buffer: 0, byteOffset: posBytes + norBytes, byteLength: idxBytes, target: 34963 },
    ],
    accessors: [
      { bufferView: 0, componentType: 5126, count: pos.length / 3, type: 'VEC3', min, max },
      { bufferView: 1, componentType: 5126, count: nor.length / 3, type: 'VEC3' },
      { bufferView: 2, componentType: 5123, count: idx.length, type: 'SCALAR' },
    ],
  };

  let json = Buffer.from(JSON.stringify(gltf), 'utf8');
  json = Buffer.concat([json, Buffer.alloc(pad4(json.length) - json.length, 0x20)]);

  const bin = Buffer.alloc(binLength);
  Buffer.from(pos.buffer).copy(bin, 0);
  Buffer.from(nor.buffer).copy(bin, posBytes);
  Buffer.from(idx.buffer).copy(bin, posBytes + norBytes);

  const header = Buffer.alloc(12);
  const total = 12 + 8 + json.length + 8 + bin.length;
  header.writeUInt32LE(0x46546c67, 0); // «glTF»
  header.writeUInt32LE(2, 4);
  header.writeUInt32LE(total, 8);

  const jsonHead = Buffer.alloc(8);
  jsonHead.writeUInt32LE(json.length, 0);
  jsonHead.writeUInt32LE(0x4e4f534a, 4); // «JSON»

  const binHead = Buffer.alloc(8);
  binHead.writeUInt32LE(bin.length, 0);
  binHead.writeUInt32LE(0x004e4942, 4); // «BIN»

  return Buffer.concat([header, jsonHead, json, binHead, bin]);
}
