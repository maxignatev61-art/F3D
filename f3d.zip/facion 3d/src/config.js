// Все настройки сервера читаются из файла .env (см. .env.example).
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');

const num = (value, fallback) => {
  const n = Number(value);
  return value === undefined || value === '' || Number.isNaN(n) ? fallback : n;
};

const list = (value) =>
  (value || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

export const config = {
  port: num(process.env.PORT, 3000),
  dataDir: path.resolve(root, process.env.DATA_DIR || 'data'),
  publicDir: path.join(root, 'public'),
  maxUploadMb: num(process.env.MAX_UPLOAD_MB, 10),
  // Если короткая сторона картинки меньше — предупреждаем, но не запрещаем.
  minRecommendedSide: 512,
  defaultProvider: (process.env.DEFAULT_PROVIDER || 'tripo').trim().toLowerCase(),
  // Адреса фронтенда на другом порту/домене, которым можно обращаться к API.
  // localhost и 127.0.0.1 на любом порту разрешены всегда.
  corsOrigins: list(process.env.CORS_ORIGINS),
  // За хостингом (nginx, Render и т.п.) сервер видит https через прокси.
  trustProxy: num(process.env.TRUST_PROXY, 0),
  // Первый администратор: создаётся при запуске, если пользователей ещё нет.
  adminLogin: (process.env.ADMIN_LOGIN || '').trim(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  // Сколько генераций в день можно одному пользователю (0 — без лимита).
  dailyLimit: num(process.env.DAILY_LIMIT, 10),
  sessionDays: num(process.env.SESSION_DAYS, 30),
  pollIntervalMs: num(process.env.POLL_INTERVAL_MS, 3000),
  taskTimeoutMin: num(process.env.TASK_TIMEOUT_MIN, 15),

  tripo: {
    apiKey: (process.env.TRIPO_API_KEY || '').trim(),
    baseUrl: process.env.TRIPO_BASE_URL || 'https://openapi.tripo3d.ai/v3',
    model: process.env.TRIPO_MODEL || 'v3.1-20260211',
  },
  meshy: {
    apiKey: (process.env.MESHY_API_KEY || '').trim(),
    baseUrl: process.env.MESHY_BASE_URL || 'https://api.meshy.ai/openapi/v1',
    aiModel: process.env.MESHY_AI_MODEL || 'latest',
  },
  mock: {
    // Сколько секунд «генерирует» тестовый режим.
    durationSec: num(process.env.MOCK_DURATION_SEC, 20),
  },
};
