// Точка входа сервера «Эскиз → 3D».
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import express from 'express';
import multer from 'multer';
import cors from 'cors';
import { config } from './config.js';
import { db, initDb, users } from './db.js';
import { AppError, MESSAGES } from './errors.js';
import { normalizeImage } from './images.js';
import {
  assertWithinLimit,
  authenticate,
  checkPassword,
  cleanupSessions,
  createUser,
  dropSessions,
  ensureAdmin,
  generatePassword,
  hashPassword,
  login,
  logout,
  publicUser,
  requireAdmin,
  requireUser,
  verifyPassword,
} from './auth.js';
import {
  GARMENT_TYPES,
  QUALITIES,
  createAndSubmit,
  deleteModel,
  normalizeGarmentType,
  parseGarmentType,
  parseName,
  parseOptions,
  startGeneration,
  startPoller,
  view,
} from './models.js';
import { getProvider, providers } from './providers/index.js';
import { ensureDirs, filePath } from './storage.js';
import { initSigning, verifyFileUrl } from './signed-urls.js';

const root = path.resolve(import.meta.dirname, '..');
const pagesDir = path.join(root, 'pages');
const pwaDir = path.join(root, 'pwa');

const app = express();
app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', config.trustProxy);

// ---------- Доступ с фронтенда на другом порту (разработка) ----------
const localOrigin = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/;
const corsOptions = {
  credentials: true,
  origin: (origin, cb) => cb(null, !origin || localOrigin.test(origin) || config.corsOrigins.includes(origin)),
};
app.use('/api', cors(corsOptions));
// Файлы защищены подписью в ссылке, поэтому их можно грузить с любого адреса
// (3D-просмотрщик скачивает модель через fetch).
app.use('/files', cors());
app.use(express.json({ limit: '100kb' }));
app.use(authenticate);

// ---------- Загрузка файла ----------
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 1, fields: 20 },
});

// Браузеры присылают русские имена файлов в UTF-8, а multer читает их как latin1.
function fixFileName(name = '') {
  if (/[^\u0000-ÿ]/.test(name)) return name;
  const fixed = Buffer.from(name, 'latin1').toString('utf8');
  return fixed.includes('�') ? name : fixed;
}

const nameFromFile = (fileName) => path.parse(fileName).name.trim().slice(0, 60) || null;

// Модель видна только владельцу (администратор видит все).
function findModel(req, id) {
  const model = db.get(id);
  if (!model || (model.userId !== req.user.id && req.user.role !== 'admin')) throw new AppError('NOT_FOUND', 404);
  return model;
}

// Пока запрос на генерацию обрабатывается, он уже считается в лимите —
// иначе два быстрых нажатия обойдут ограничение.
const submitting = new Set();
async function withGenerationSlot(user, fn) {
  if (submitting.has(user.id)) throw new AppError('RATE_LIMITED', 429, 'Предыдущий эскиз ещё отправляется');
  assertWithinLimit(user);
  submitting.add(user.id);
  try {
    return await fn();
  } finally {
    submitting.delete(user.id);
  }
}

const api = express.Router();

// ---------- Открытые адреса ----------

api.get('/health', (_req, res) => res.json({ ok: true }));

// Настройки для формы. Доступны и без входа (для экрана логина).
api.get('/config', (_req, res) => {
  res.json({
    defaultProvider: config.defaultProvider,
    providers: Object.values(providers).map((p) => ({ id: p.id, name: p.name, configured: p.configured() })),
    maxUploadMb: config.maxUploadMb,
    acceptedFormats: ['jpg', 'png', 'webp'],
    minRecommendedSide: config.minRecommendedSide,
    limits: {
      maxFileSizeBytes: config.maxUploadMb * 1024 * 1024,
      minImageSide: config.minRecommendedSide,
    },
    garmentTypes: GARMENT_TYPES,
    qualities: QUALITIES,
    pollIntervalMs: config.pollIntervalMs,
    taskTimeoutMin: config.taskTimeoutMin,
    messages: MESSAGES,
  });
});

// ---------- Вход и аккаунт ----------

// Ответ содержит token: фронтенд с другого адреса отправляет его в заголовке
// «Authorization: Bearer <token>». Страницам самого сервера хватает cookie.
api.post('/auth/login', async (req, res) => {
  const { user, token } = await login(req, res, req.body?.login, req.body?.password);
  res.json({ user: publicUser(user), token });
});

api.post('/auth/logout', async (req, res) => {
  await logout(req, res);
  res.status(204).end();
});

api.get('/me', requireUser, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

api.post('/me/password', requireUser, async (req, res) => {
  if (!(await verifyPassword(String(req.body?.currentPassword ?? ''), req.user.passwordHash))) {
    throw new AppError('WRONG_PASSWORD', 400);
  }
  const passwordHash = await hashPassword(checkPassword(req.body?.newPassword));
  await users.update(req.user.id, { passwordHash });
  // Выходим на других устройствах, текущий вход сохраняем через новую сессию.
  await dropSessions(req.user.id);
  const { token } = await login(req, res, req.user.login, req.body.newPassword);
  res.json({ token });
});

// Выбор сервиса генерации доступен только администратору:
// обычные пользователи всегда работают через основной сервис.
function generationBody(req) {
  const body = { ...(req.body || {}) };
  if (req.user.role !== 'admin') delete body.provider;
  return body;
}

// ---------- Генерация и галерея (нужен вход) ----------

// Запуск генерации: multipart/form-data, файл в поле «image».
api.post('/generate', requireUser, upload.single('image'), async (req, res) => {
  if (!req.file) throw new AppError('NO_FILE', 400);
  const originalName = fixFileName(req.file.originalname);
  const options = parseOptions(generationBody(req), { name: nameFromFile(originalName) });
  const image = await normalizeImage(req.file.buffer);

  const model = await withGenerationSlot(req.user, () =>
    startGeneration({ userId: req.user.id, image, options, hints: { fail: /fail/i.test(originalName) } }),
  );

  const warnings = [];
  if (Math.min(image.width, image.height) < config.minRecommendedSide) warnings.push('SMALL_IMAGE');
  res.status(202).json({ model: view(model), warnings });
});

// Статус генерации. Фронтенд опрашивает его каждые несколько секунд.
api.get('/tasks/:id', requireUser, (req, res) => {
  res.json({ model: view(findModel(req, req.params.id)) });
});

// Галерея пользователя. Фильтры: ?search=текст&type=dress&status=success
api.get('/models', requireUser, (req, res) => {
  const search = String(req.query.search || '').trim().toLowerCase();
  const type = normalizeGarmentType(String(req.query.type || ''));
  const status = String(req.query.status || '');
  const models = db
    .filter((m) => m.userId === req.user.id)
    .filter((m) => !search || m.name.toLowerCase().includes(search))
    .filter((m) => !type || m.garmentType === type)
    .filter((m) => !status || m.status === status)
    .toSorted((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map(view);
  res.json({ models });
});

api.get('/models/:id', requireUser, (req, res) => {
  res.json({ model: view(findModel(req, req.params.id)) });
});

// Переименование и смена типа изделия.
api.patch('/models/:id', requireUser, async (req, res) => {
  findModel(req, req.params.id);
  const patch = {};
  if (req.body?.name !== undefined) patch.name = parseName(req.body.name);
  if (req.body?.garmentType !== undefined) patch.garmentType = parseGarmentType(req.body.garmentType);
  if (!Object.keys(patch).length) throw new AppError('BAD_REQUEST', 400, 'Нечего менять: передайте name или garmentType');
  const model = await db.update(req.params.id, patch);
  res.json({ model: view(model) });
});

api.delete('/models/:id', requireUser, async (req, res) => {
  findModel(req, req.params.id);
  await deleteModel(req.params.id);
  res.status(204).end();
});

// «Создать заново» из того же эскиза. Настройки можно поменять в теле запроса.
api.post('/models/:id/regenerate', requireUser, async (req, res) => {
  const source = findModel(req, req.params.id);
  const options = parseOptions(generationBody(req), {
    provider: req.user.role === 'admin' ? source.provider : config.defaultProvider,
    quality: source.quality,
    texture: source.texture,
    garmentType: source.garmentType,
    name: source.name,
  });
  const buffer = await fs.readFile(filePath('sketches', source.sketchFile));
  const image = await normalizeImage(buffer);

  const model = await withGenerationSlot(req.user, async () => {
    const sketchFile = `${randomUUID()}.${image.ext}`;
    await fs.writeFile(filePath('sketches', sketchFile), image.buffer);
    return createAndSubmit({ userId: req.user.id, image, sketchFile, options, hints: {} });
  });
  res.status(202).json({ model: view(model), warnings: [] });
});

// Скачивание GLB с понятным именем файла.
api.get('/models/:id/download', requireUser, (req, res) => {
  const model = findModel(req, req.params.id);
  if (!model.modelFile) throw new AppError('NOT_READY', 409);
  const safeName = model.name.replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'model';
  res.download(filePath('models', model.modelFile), `${safeName}.glb`);
});

// ---------- Администратор ----------

// Остаток кредитов: ?provider=tripo (по умолчанию — основной сервис).
api.get('/balance', requireAdmin, async (req, res) => {
  const provider = getProvider(String(req.query.provider || config.defaultProvider));
  if (!provider) throw new AppError('BAD_REQUEST', 400, 'provider: tripo, meshy или mock');
  if (!provider.configured()) throw new AppError('PROVIDER_NOT_CONFIGURED', 503);
  res.json({ provider: provider.id, ...(await provider.getBalance()) });
});

const parseLimit = (value) => {
  if (value === null || value === '') return null; // общий лимит из настроек
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0 || n > 1000) throw new AppError('BAD_REQUEST', 400, 'dailyLimit: целое число 0–1000 или null');
  return n;
};

const adminView = (u) => ({
  ...publicUser(u),
  customLimit: u.dailyLimit ?? null, // null — действует общий лимит
  modelsTotal: db.filter((m) => m.userId === u.id).length,
  creditsUsed: db.filter((m) => m.userId === u.id).reduce((sum, m) => sum + (Number(m.creditsUsed) || 0), 0),
});

const findUser = (id) => {
  const user = users.get(id);
  if (!user) throw new AppError('NOT_FOUND', 404, 'Пользователь не найден');
  return user;
};

api.get('/admin/users', requireAdmin, (_req, res) => {
  const list = users.all().toSorted((a, b) => a.login.localeCompare(b.login)).map(adminView);
  res.json({ users: list, defaultDailyLimit: config.dailyLimit });
});

// Новый пользователь. Если пароль не передан — создаётся случайный и
// возвращается один раз в ответе, чтобы передать его человеку.
api.post('/admin/users', requireAdmin, async (req, res) => {
  const password = req.body?.password || generatePassword();
  const user = await createUser({
    login: req.body?.login,
    name: req.body?.name,
    password,
    role: req.body?.role || 'user',
    dailyLimit: req.body?.dailyLimit === undefined ? null : parseLimit(req.body.dailyLimit),
  });
  res.status(201).json({ user: adminView(user), password });
});

api.patch('/admin/users/:id', requireAdmin, async (req, res) => {
  const user = findUser(req.params.id);
  const body = req.body || {};
  const patch = {};
  if (body.name !== undefined) patch.name = String(body.name).trim().slice(0, 60) || user.login;
  if (body.dailyLimit !== undefined) patch.dailyLimit = parseLimit(body.dailyLimit);
  if (body.role !== undefined) {
    if (!['user', 'admin'].includes(body.role)) throw new AppError('BAD_REQUEST', 400, 'role: user или admin');
    patch.role = body.role;
  }
  if (body.disabled !== undefined) patch.disabled = Boolean(body.disabled);
  if ((patch.role === 'user' || patch.disabled) && user.id === req.user.id) {
    throw new AppError('BAD_REQUEST', 400, 'Нельзя отключить или понизить самого себя');
  }
  let password;
  if (body.resetPassword) {
    password = generatePassword();
    patch.passwordHash = await hashPassword(password);
  }
  await users.update(user.id, patch);
  if (patch.disabled || password) await dropSessions(user.id);
  res.json({ user: adminView(users.get(user.id)), ...(password ? { password } : {}) });
});

api.use(() => {
  throw new AppError('NOT_FOUND', 404, 'Нет такого адреса API');
});

app.use('/api', api);

// ---------- Файлы: эскизы, модели, превью ----------
// Открываются по подписанной ссылке из ответа API или владельцем после входа.
const FILE_NAME = /^([0-9a-f-]{36})\.(png|jpg|webp|glb)$/;
app.get('/files/:kind/:name', (req, res) => {
  const { kind, name } = req.params;
  const match = FILE_NAME.exec(name);
  if (!['sketches', 'models', 'previews'].includes(kind) || !match) throw new AppError('NOT_FOUND', 404);

  const model = db.get(match[1]);
  if (!model) throw new AppError('NOT_FOUND', 404);
  if (!verifyFileUrl(kind, name, req.query)) {
    if (!req.user) throw new AppError('UNAUTHORIZED', 401);
    findModel(req, model.id);
  }

  const headers = {
    'Cache-Control': 'private, max-age=3600',
    ...(name.endsWith('.glb') ? { 'Content-Type': 'model/gltf-binary' } : {}),
  };
  if (req.query.dl === '1') {
    const safeName = model.name.replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'model';
    return res.download(filePath(kind, name), `${safeName}${path.extname(name)}`, { headers });
  }
  res.sendFile(filePath(kind, name), { headers });
});

// ---------- Страницы ----------
// /dev — проверка сервера, /admin — управление пользователями.
app.use(express.static(pagesDir));
// Готовая сборка фронтенда (папка public/).
app.use(express.static(config.publicDir));
// Иконки и файлы установки приложения — если во фронтенде нет своих.
app.use(express.static(pwaDir));
// Фронтенд с переходами по страницам: неизвестные адреса отдаём index.html.
app.get(/^\/(?!api\/|files\/).*/, (req, res, next) => {
  const index = path.join(config.publicDir, 'index.html');
  if (req.accepts('html') && existsSync(index)) return res.sendFile(index);
  next();
});

// ---------- Ошибки ----------
app.use((err, _req, res, _next) => {
  let error = err;
  if (err instanceof multer.MulterError) {
    error =
      err.code === 'LIMIT_FILE_SIZE'
        ? new AppError('FILE_TOO_LARGE', 413)
        : new AppError('BAD_REQUEST', 400, `${err.code}${err.field ? `: ${err.field}` : ''}`);
  } else if (err.type === 'entity.parse.failed') {
    error = new AppError('BAD_REQUEST', 400, 'Неверный JSON');
  } else if ((err.status === 404 || err.code === 'ENOENT') && !(err instanceof AppError)) {
    error = new AppError('NOT_FOUND', 404, 'Файл не найден');
  } else if (!(err instanceof AppError)) {
    console.error('[server]', err);
    error = new AppError('INTERNAL', 500);
  }
  res.status(error.status).json({
    error: { code: error.code, message: error.message, ...(error.details ? { details: error.details } : {}) },
  });
});

// ---------- Запуск ----------
await ensureDirs();
await initDb();
await initSigning();
await ensureAdmin();
// Старые названия типов одежды → новые (tshirt → t-shirt, pants → trousers).
for (const m of db.filter((m) => normalizeGarmentType(m.garmentType) !== m.garmentType)) {
  await db.update(m.id, { garmentType: normalizeGarmentType(m.garmentType) });
}
startPoller();
await cleanupSessions();
setInterval(cleanupSessions, 60 * 60_000);

app.listen(config.port, () => {
  console.log(`Сервер запущен: http://localhost:${config.port}`);
  console.log(`Администрирование: http://localhost:${config.port}/admin/`);
  console.log(`Проверка: http://localhost:${config.port}/dev/`);
  const main = getProvider(config.defaultProvider);
  if (!main) console.warn(`! DEFAULT_PROVIDER="${config.defaultProvider}" — такого сервиса нет (tripo, meshy, mock).`);
  else if (!main.configured()) console.warn(`! Основной сервис ${main.name} без ключа API — заполните .env.`);
  else console.log(`Основной сервис: ${main.name}`);
});
