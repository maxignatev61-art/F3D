// Простое хранилище в файле data/db.json: модели, пользователи, сессии входа.
// Для одного сервера и сотен пользователей этого достаточно.
import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';

const COLLECTIONS = ['models', 'users', 'sessions'];

let state = {};
let file;
let writing = Promise.resolve();

export async function initDb() {
  file = path.join(config.dataDir, 'db.json');
  await fs.mkdir(config.dataDir, { recursive: true });
  try {
    state = JSON.parse(await fs.readFile(file, 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
  for (const name of COLLECTIONS) state[name] ??= [];
}

// Записи идут строго по очереди, чтобы файл не повредился.
function persist() {
  const snapshot = JSON.stringify(state, null, 2);
  writing = writing
    .then(async () => {
      const tmp = `${file}.tmp`;
      await fs.writeFile(tmp, snapshot);
      try {
        await fs.rename(tmp, file);
      } catch {
        // На Windows замена иногда блокируется антивирусом — пишем напрямую.
        await fs.writeFile(file, snapshot);
        await fs.rm(tmp, { force: true });
      }
    })
    .catch((err) => console.error('[db] Не удалось сохранить базу:', err));
  return writing;
}

function collection(name) {
  const items = () => state[name];
  const api = {
    all: () => items(),
    get: (id) => items().find((x) => x.id === id) || null,
    find: (fn) => items().find(fn) || null,
    filter: (fn) => items().filter(fn),

    async insert(item) {
      items().push(item);
      await persist();
      return item;
    },

    async update(id, patch) {
      const item = api.get(id);
      if (!item) return null;
      Object.assign(item, patch, { updatedAt: new Date().toISOString() });
      await persist();
      return item;
    },

    async remove(id) {
      const index = items().findIndex((x) => x.id === id);
      if (index === -1) return null;
      const [removed] = items().splice(index, 1);
      await persist();
      return removed;
    },

    async removeWhere(fn) {
      const before = items().length;
      state[name] = items().filter((x) => !fn(x));
      if (state[name].length !== before) await persist();
      return before - state[name].length;
    },
  };
  return api;
}

export const db = collection('models');
export const users = collection('users');
export const sessions = collection('sessions');
