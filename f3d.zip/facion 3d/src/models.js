// Запуск генерации, слежение за заданиями и сохранение результатов.
import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from './config.js';
import { db } from './db.js';
import { AppError, errorInfo } from './errors.js';
import { toAcceptedFormat } from './images.js';
import { getProvider } from './providers/index.js';
import { download, filePath, isGlb, removeQuiet } from './storage.js';
import { signedFileUrl } from './signed-urls.js';

// value — то же, что id: так тип понимают и фронтенды, которые ждут поле value.
export const GARMENT_TYPES = [
  { id: 'dress', value: 'dress', label: 'Платье' },
  { id: 't-shirt', value: 't-shirt', label: 'Футболка' },
  { id: 'shirt', value: 'shirt', label: 'Рубашка' },
  { id: 'jacket', value: 'jacket', label: 'Куртка' },
  { id: 'trousers', value: 'trousers', label: 'Брюки' },
  { id: 'skirt', value: 'skirt', label: 'Юбка' },
  { id: 'other', value: 'other', label: 'Другое' },
];

// Старые названия типов, которые тоже принимаются.
const GARMENT_ALIASES = { tshirt: 't-shirt', pants: 'trousers' };
export const normalizeGarmentType = (value) => GARMENT_ALIASES[value] || value;

export const QUALITIES = [
  { id: 'standard', value: 'standard', label: 'Стандарт' },
  { id: 'high', value: 'high', label: 'Высокое' },
];

const ACTIVE = new Set(['queued', 'running']);
const NAME_MAX = 60;

// Модель в том виде, в котором её видит фронтенд.
export function view(m) {
  return {
    id: m.id,
    name: m.name,
    garmentType: m.garmentType,
    provider: m.provider,
    texture: m.texture,
    quality: m.quality,
    status: m.status,
    progress: m.progress,
    error: m.error,
    sketchUrl: signedFileUrl('sketches', m.sketchFile),
    sketchWidth: m.sketchWidth,
    sketchHeight: m.sketchHeight,
    modelUrl: signedFileUrl('models', m.modelFile),
    previewUrl: signedFileUrl('previews', m.previewFile),
    downloadUrl: signedFileUrl('models', m.modelFile, { download: true }),
    creditsUsed: m.creditsUsed,
    createdAt: m.createdAt,
    updatedAt: m.updatedAt,
    completedAt: m.completedAt,
  };
}

const bad = (details) => new AppError('BAD_REQUEST', 400, details);

function parseBool(value, fallback, field) {
  if (value === undefined || value === '') return fallback;
  if (value === true || value === 'true' || value === '1') return true;
  if (value === false || value === 'false' || value === '0') return false;
  throw bad(`${field}: ожидается true или false`);
}

export function parseName(value) {
  const name = String(value ?? '').trim();
  if (!name) throw bad('name: название не может быть пустым');
  if (name.length > NAME_MAX) throw bad(`name: не длиннее ${NAME_MAX} символов`);
  return name;
}

export function parseGarmentType(raw) {
  const value = normalizeGarmentType(raw);
  if (!GARMENT_TYPES.some((t) => t.id === value)) {
    throw bad(`garmentType: одно из ${GARMENT_TYPES.map((t) => t.id).join(', ')}`);
  }
  return value;
}

/** Разбирает настройки генерации из запроса; `base` — значения по умолчанию. */
export function parseOptions(body = {}, base = {}) {
  const provider = String(body.provider || base.provider || config.defaultProvider).toLowerCase();
  if (!getProvider(provider)) throw bad('provider: tripo, meshy или mock');

  const quality = body.quality || base.quality || 'standard';
  if (!QUALITIES.some((q) => q.id === quality)) throw bad('quality: standard или high');

  return {
    provider,
    quality,
    texture: parseBool(body.texture, base.texture ?? true, 'texture'),
    garmentType: parseGarmentType(body.garmentType || base.garmentType || 'other'),
    name: body.name !== undefined && body.name !== '' ? parseName(body.name) : base.name || null,
  };
}

/**
 * Создаёт запись и отправляет задание в сервис генерации.
 * Если сервис сразу отказал (нет кредитов, неверный ключ) — запись не создаётся,
 * эскиз удаляется, а ошибка уходит фронтенду.
 */
export async function createAndSubmit({ userId, image, sketchFile, options, hints }) {
  const provider = getProvider(options.provider);
  if (!provider.configured()) throw new AppError('PROVIDER_NOT_CONFIGURED', 503, `${provider.name}: нет ключа в .env`);

  const id = path.parse(sketchFile).name;
  let providerTaskId;
  try {
    const prepared = await toAcceptedFormat(image, provider.acceptedFormats);
    providerTaskId = await provider.createTask({
      image: prepared,
      texture: options.texture,
      quality: options.quality,
      hints,
    });
  } catch (err) {
    await removeQuiet(filePath('sketches', sketchFile));
    throw err;
  }

  const now = new Date().toISOString();
  const model = await db.insert({
    id,
    userId,
    name: options.name || 'Без названия',
    garmentType: options.garmentType,
    provider: provider.id,
    texture: options.texture,
    quality: options.quality,
    status: 'queued',
    progress: 0,
    error: null,
    providerTaskId,
    sketchFile,
    sketchWidth: image.width,
    sketchHeight: image.height,
    modelFile: null,
    previewFile: null,
    creditsUsed: null,
    createdAt: now,
    updatedAt: now,
    completedAt: null,
  });
  console.log(`[gen] ${model.id} → ${provider.name}, задание ${providerTaskId}`);
  return model;
}

/** Сохраняет эскиз на диск и запускает генерацию. */
export async function startGeneration({ userId, image, options, hints }) {
  const sketchFile = `${randomUUID()}.${image.ext}`;
  await fs.writeFile(filePath('sketches', sketchFile), image.buffer);
  return createAndSubmit({ userId, image, sketchFile, options, hints });
}

// ---------- Слежение за заданиями ----------

const inflight = new Set();

async function fail(model, code, details) {
  console.warn(`[gen] ${model.id} — ошибка ${code}${details ? `: ${details}` : ''}`);
  await db.update(model.id, { status: 'failed', error: errorInfo(code, details) });
}

const previewExt = (contentType) =>
  contentType.includes('jpeg') ? 'jpg' : contentType.includes('webp') ? 'webp' : 'png';

async function saveResult(model, provider, task) {
  const modelFile = `${model.id}.glb`;
  const modelPath = filePath('models', modelFile);
  let previewFile = null;

  if (provider.saveResult) {
    previewFile = `${model.id}${path.extname(model.sketchFile)}`;
    await provider.saveResult(task, {
      modelPath,
      previewPath: filePath('previews', previewFile),
      sketchPath: filePath('sketches', model.sketchFile),
    });
  } else {
    if (!task.modelUrl) throw new Error('Сервис не вернул ссылку на модель');
    await download(task.modelUrl, modelPath);
    if (task.previewUrl) {
      const tmp = filePath('previews', `${model.id}.download`);
      try {
        const type = await download(task.previewUrl, tmp);
        previewFile = `${model.id}.${previewExt(type)}`;
        await fs.rename(tmp, filePath('previews', previewFile));
      } catch (err) {
        // Превью не обязательно — модель всё равно сохраняем.
        console.warn(`[gen] ${model.id}: не удалось скачать превью: ${err.message}`);
        await removeQuiet(tmp);
        previewFile = null;
      }
    }
  }

  if (!(await isGlb(modelPath))) {
    await removeQuiet(modelPath);
    throw new Error('Скачанный файл не является GLB');
  }

  // Модель могли удалить, пока шло скачивание.
  if (!db.get(model.id)) {
    await removeQuiet(modelPath);
    if (previewFile) await removeQuiet(filePath('previews', previewFile));
    return;
  }

  await db.update(model.id, {
    status: 'success',
    progress: 100,
    error: null,
    modelFile,
    previewFile,
    creditsUsed: task.credits ?? null,
    completedAt: new Date().toISOString(),
  });
  console.log(`[gen] ${model.id} — готово`);
}

async function checkOne(model) {
  const provider = getProvider(model.provider);
  const ageMin = (Date.now() - Date.parse(model.createdAt)) / 60_000;
  if (!provider) return fail(model, 'INTERNAL', `Неизвестный сервис: ${model.provider}`);

  try {
    const task = await provider.getTask(model.providerTaskId);

    if (task.status === 'success') {
      try {
        await saveResult(model, provider, task);
      } catch (err) {
        // Ссылки на файл живут недолго — при сбое попробуем ещё раз на следующем круге.
        console.warn(`[gen] ${model.id}: не удалось сохранить результат: ${err.message}`);
        if (ageMin > config.taskTimeoutMin) await fail(model, 'GENERATION_FAILED', err.message);
      }
      return;
    }
    if (task.status === 'failed') {
      await db.update(model.id, { status: 'failed', error: task.error || errorInfo('GENERATION_FAILED') });
      console.warn(`[gen] ${model.id} — сервис вернул ошибку`);
      return;
    }
    if (ageMin > config.taskTimeoutMin) return fail(model, 'TIMEOUT');

    const progress = Math.max(0, Math.min(99, Math.round(task.progress)));
    if (task.status !== model.status || progress !== model.progress) {
      await db.update(model.id, { status: task.status, progress });
    }
  } catch (err) {
    if (err instanceof AppError && ['INVALID_API_KEY', 'PROVIDER_NOT_CONFIGURED'].includes(err.code)) {
      return fail(model, err.code, err.details);
    }
    // Временный сбой связи — пробуем снова, пока не выйдет время.
    console.warn(`[gen] ${model.id}: не удалось узнать статус: ${err.details || err.message}`);
    if (ageMin > config.taskTimeoutMin) await fail(model, 'TIMEOUT', err.details || err.message);
  }
}

async function tick() {
  const pending = db.all().filter((m) => ACTIVE.has(m.status) && !inflight.has(m.id));
  await Promise.allSettled(
    pending.map(async (m) => {
      inflight.add(m.id);
      try {
        await checkOne(m);
      } finally {
        inflight.delete(m.id);
      }
    }),
  );
}

// Опрос идёт на сервере, поэтому генерация не теряется,
// даже если пользователь закрыл вкладку или сервер перезапустился.
export function startPoller() {
  tick();
  return setInterval(tick, config.pollIntervalMs);
}

export async function deleteModel(id) {
  const model = await db.remove(id);
  if (!model) return null;
  await removeQuiet(filePath('sketches', model.sketchFile));
  if (model.modelFile) await removeQuiet(filePath('models', model.modelFile));
  if (model.previewFile) await removeQuiet(filePath('previews', model.previewFile));
  return model;
}
