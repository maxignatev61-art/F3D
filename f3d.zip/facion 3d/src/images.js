// Проверка и подготовка картинок-эскизов.
import sharp from 'sharp';
import { AppError } from './errors.js';

const FORMATS = {
  jpeg: { ext: 'jpg', mime: 'image/jpeg' },
  png: { ext: 'png', mime: 'image/png' },
  webp: { ext: 'webp', mime: 'image/webp' },
};

// Ограничение на размер в пикселях, чтобы «картинка-бомба» не съела память.
const MAX_PIXELS = 50_000_000;

/**
 * Проверяет, что файл — картинка JPG/PNG/WEBP, и поворачивает её
 * по EXIF (фото с телефона часто «лежат на боку»).
 * Возвращает { buffer, format, ext, mime, width, height }.
 */
export async function normalizeImage(input) {
  let meta;
  try {
    meta = await sharp(input, { limitInputPixels: MAX_PIXELS }).metadata();
  } catch {
    throw new AppError('INVALID_FORMAT', 400);
  }
  const format = FORMATS[meta.format];
  if (!format) throw new AppError('INVALID_FORMAT', 400, `format: ${meta.format}`);

  const needsRotate = meta.orientation && meta.orientation !== 1;
  let buffer = input;
  if (needsRotate) {
    buffer = await sharp(input, { limitInputPixels: MAX_PIXELS })
      .autoOrient()
      .toFormat(meta.format, { quality: 92 })
      .toBuffer();
  }
  const { width, height } = needsRotate ? await sharp(buffer).metadata() : meta;
  return { buffer, format: meta.format, ...format, width, height };
}

/**
 * Готовит картинку для сервиса генерации: если сервис не принимает
 * этот формат (например, Tripo не берёт WEBP), конвертирует в PNG.
 */
export async function toAcceptedFormat(image, acceptedFormats) {
  if (acceptedFormats.includes(image.format)) return image;
  const buffer = await sharp(image.buffer, { limitInputPixels: MAX_PIXELS }).png().toBuffer();
  return { ...image, buffer, format: 'png', ...FORMATS.png };
}
