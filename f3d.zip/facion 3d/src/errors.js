import { config } from './config.js';

// Тексты для пользователя. Фронтенд может показывать `message` как есть
// или подставлять свой текст по `code`.
export const MESSAGES = {
  NO_FILE: 'Добавьте картинку с эскизом.',
  INVALID_FORMAT: 'Этот файл не подходит. Загрузите JPG, PNG или WEBP.',
  FILE_TOO_LARGE: `Файл слишком большой. Уменьшите картинку до ${config.maxUploadMb} МБ.`,
  BAD_REQUEST: 'Неверные параметры запроса.',
  NOT_FOUND: 'Модель не найдена.',
  NOT_READY: 'Модель ещё не готова.',
  UNAUTHORIZED: 'Войдите в аккаунт.',
  FORBIDDEN: 'Недостаточно прав.',
  LOGIN_FAILED: 'Неверный логин или пароль.',
  TOO_MANY_ATTEMPTS: 'Слишком много попыток входа. Подождите 15 минут.',
  WRONG_PASSWORD: 'Текущий пароль указан неверно.',
  WEAK_PASSWORD: 'Пароль должен быть не короче 8 символов.',
  LOGIN_TAKEN: 'Такой логин уже занят.',
  LIMIT_REACHED: 'Лимит генераций на сегодня исчерпан. Попробуйте завтра.',
  PROVIDER_NOT_CONFIGURED: 'Сервис генерации не настроен: на сервере нет ключа API.',
  INVALID_API_KEY: 'Ключ API не подходит. Проверьте его в настройках сервера.',
  NO_CREDITS: 'На счёте сервиса закончились кредиты. Пополните баланс.',
  RATE_LIMITED: 'Слишком много генераций одновременно. Подождите немного и попробуйте снова.',
  CONTENT_REJECTED: 'Сервис отклонил картинку. Попробуйте другой эскиз.',
  PROVIDER_UNAVAILABLE: 'Нет связи с сервисом генерации. Проверьте интернет и попробуйте ещё раз.',
  GENERATION_FAILED: 'Не получилось. Попробуйте другой эскиз: вещь целиком на светлом фоне.',
  TIMEOUT: 'Сервис не отвечает. Попробуйте снова чуть позже.',
  INTERNAL: 'Что-то пошло не так на сервере. Попробуйте ещё раз.',
};

export class AppError extends Error {
  /**
   * @param {keyof MESSAGES} code  машинный код ошибки
   * @param {number} status        HTTP-статус ответа
   * @param {string} [details]     техническая подробность (например, ответ сервиса)
   */
  constructor(code, status = 400, details) {
    super(MESSAGES[code] || code);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

// Ошибка в виде, который хранится в модели и отдаётся фронтенду.
export const errorInfo = (code, details) => ({
  code,
  message: MESSAGES[code] || MESSAGES.INTERNAL,
  ...(details ? { details: String(details).slice(0, 500) } : {}),
});
