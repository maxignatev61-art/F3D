// Файлы на диске: эскизы, готовые модели и превью.
import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { config } from './config.js';

const filesRoot = path.join(config.dataDir, 'files');

export const dirs = {
  root: filesRoot,
  sketches: path.join(filesRoot, 'sketches'),
  models: path.join(filesRoot, 'models'),
  previews: path.join(filesRoot, 'previews'),
};

export async function ensureDirs() {
  for (const dir of [dirs.sketches, dirs.models, dirs.previews]) {
    await fs.mkdir(dir, { recursive: true });
  }
}

export const filePath = (kind, name) => path.join(dirs[kind], name);

// Публичный адрес файла для фронтенда.
export const fileUrl = (kind, name) => (name ? `/files/${kind}/${encodeURIComponent(name)}` : null);

export async function removeQuiet(file) {
  if (!file) return;
  await fs.rm(file, { force: true }).catch(() => {});
}

// Скачивает файл по ссылке. Возвращает Content-Type ответа.
export async function download(url, dest) {
  const res = await fetch(url, { signal: AbortSignal.timeout(5 * 60_000) });
  if (!res.ok || !res.body) throw new Error(`Download failed: HTTP ${res.status}`);
  const tmp = `${dest}.part`;
  try {
    await pipeline(Readable.fromWeb(res.body), createWriteStream(tmp));
    await fs.rename(tmp, dest);
  } catch (err) {
    await removeQuiet(tmp);
    throw err;
  }
  return res.headers.get('content-type') || '';
}

// Проверяет, что файл действительно GLB (начинается с «glTF»).
export async function isGlb(file) {
  const handle = await fs.open(file, 'r');
  try {
    const buf = Buffer.alloc(4);
    await handle.read(buf, 0, 4, 0);
    return buf.toString('latin1') === 'glTF';
  } finally {
    await handle.close();
  }
}
