// Tripo API V3: https://developers.tripo3d.ai/en/docs/introduction
// Порядок: загрузить картинку (POST /files) → создать задание
// (POST /generation/image-to-model) → опрашивать GET /tasks/{id}.
import { config } from '../config.js';
import { AppError, errorInfo } from '../errors.js';

const cfg = config.tripo;

function mapError(httpStatus, body) {
  const code = body?.code;
  const details = body?.message || `HTTP ${httpStatus}`;
  if (code === 2010) return new AppError('NO_CREDITS', 402, details);
  if (code === 1000 || code === 1001 || httpStatus === 401) return new AppError('INVALID_API_KEY', 503, details);
  if (code === 1007 || code === 2000 || httpStatus === 429) return new AppError('RATE_LIMITED', 429, details);
  if (code === 2008) return new AppError('CONTENT_REJECTED', 422, details);
  if (code === 2003 || code === 2004) return new AppError('INVALID_FORMAT', 400, details);
  if (httpStatus === 403) return new AppError('NO_CREDITS', 402, details);
  if (httpStatus >= 500) return new AppError('PROVIDER_UNAVAILABLE', 502, details);
  return new AppError('GENERATION_FAILED', 502, `Tripo ${code ?? httpStatus}: ${details}`);
}

async function call(method, pathname, { json, form } = {}) {
  let res;
  try {
    res = await fetch(cfg.baseUrl + pathname, {
      method,
      headers: {
        Authorization: `Bearer ${cfg.apiKey}`,
        ...(json ? { 'Content-Type': 'application/json' } : {}),
      },
      body: json ? JSON.stringify(json) : form,
      signal: AbortSignal.timeout(90_000),
    });
  } catch (err) {
    throw new AppError('PROVIDER_UNAVAILABLE', 502, err.cause?.message || err.message);
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    // Не JSON — обработаем ниже как ошибку.
  }
  if (!res.ok || !body || body.code !== 0) throw mapError(res.status, body);
  return body.data;
}

// Параметры качества поддерживаются только моделями v3.x.
const supportsQuality = () => /^v3\./.test(cfg.model);

export const tripo = {
  id: 'tripo',
  name: 'Tripo',
  acceptedFormats: ['jpeg', 'png'],
  configured: () => Boolean(cfg.apiKey),

  async createTask({ image, texture, quality }) {
    const form = new FormData();
    form.append('file', new Blob([image.buffer], { type: image.mime }), `sketch.${image.ext}`);
    const { file_token } = await call('POST', '/files', { form });

    const high = quality === 'high';
    const body = {
      input: file_token,
      model: cfg.model,
      texture,
      pbr: texture, // pbr=true сам включает текстуры, поэтому без текстур выключаем и его
    };
    if (supportsQuality()) {
      body.geometry_quality = high ? 'detailed' : 'standard';
      if (texture) body.texture_quality = high ? 'detailed' : 'standard';
    }
    const { task_id } = await call('POST', '/generation/image-to-model', { json: body });
    return task_id;
  },

  async getTask(taskId) {
    const t = await call('GET', `/tasks/${encodeURIComponent(taskId)}`);
    const out = t.output || {};
    const base = {
      progress: Number(t.progress) || 0,
      credits: t.credits_consumed ?? null,
    };
    switch (t.status) {
      case 'queued':
        return { ...base, status: 'queued' };
      case 'running':
        return { ...base, status: 'running' };
      case 'success':
        return {
          ...base,
          status: 'success',
          modelUrl: out.model_url || out.pbr_model || out.model || out.base_model,
          previewUrl: out.rendered_image_url || out.rendered_image,
        };
      case 'banned':
        return { ...base, status: 'failed', error: errorInfo('CONTENT_REJECTED') };
      case 'failed':
      case 'cancelled':
      case 'expired':
        return {
          ...base,
          status: 'failed',
          error: errorInfo('GENERATION_FAILED', `Tripo: ${t.status} ${t.error_code ?? ''} ${t.error_message ?? ''}`.trim()),
        };
      default:
        // Неизвестный статус — считаем, что задание ещё идёт.
        return { ...base, status: 'running' };
    }
  },

  async getBalance() {
    const d = await call('GET', '/account/balance');
    return { balance: Number(d.balance), frozen: Number(d.frozen ?? 0) };
  },
};
