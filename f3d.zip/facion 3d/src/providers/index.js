import { tripo } from './tripo.js';
import { meshy } from './meshy.js';
import { mock } from './mock.js';

export const providers = { tripo, meshy, mock };

export const getProvider = (id) => providers[id] || null;
