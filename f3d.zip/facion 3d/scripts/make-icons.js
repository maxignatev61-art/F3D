// Рисует иконки приложения из простого SVG.
// Запуск: node scripts/make-icons.js  (результат — в папке pwa/icons)
import path from 'node:path';
import fs from 'node:fs/promises';
import sharp from 'sharp';

const out = path.resolve(import.meta.dirname, '..', 'pwa', 'icons');
await fs.mkdir(out, { recursive: true });

// Силуэт платья на фиолетовом фоне. inset — отступ для «маскируемой» иконки,
// которую Android обрезает кругом или квадратом со скруглением.
const svg = (inset = 0) => {
  const s = 512;
  const k = (s - inset * 2) / s;
  const t = (v) => inset + v * k;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">
  <rect width="${s}" height="${s}" rx="${inset ? 0 : 112}" fill="#6a4cff"/>
  <path fill="#ffffff" d="
    M ${t(196)} ${t(92)} L ${t(220)} ${t(92)}
    L ${t(232)} ${t(150)} Q ${t(256)} ${t(178)} ${t(280)} ${t(150)}
    L ${t(292)} ${t(92)} L ${t(316)} ${t(92)}
    L ${t(324)} ${t(176)} Q ${t(318)} ${t(220)} ${t(296)} ${t(252)}
    L ${t(404)} ${t(412)} Q ${t(256)} ${t(448)} ${t(108)} ${t(412)}
    L ${t(216)} ${t(252)} Q ${t(194)} ${t(220)} ${t(188)} ${t(176)} Z"/>
  <path fill="none" stroke="#6a4cff" stroke-width="${10 * k}" stroke-linecap="round" d="M ${t(212)} ${t(258)} Q ${t(256)} ${t(272)} ${t(300)} ${t(258)}"/>
</svg>`;
};

const jobs = [
  ['icon-192.png', 192, 0],
  ['icon-512.png', 512, 0],
  ['icon-maskable-512.png', 512, 80],
  ['apple-touch-icon.png', 180, 40],
  ['favicon-32.png', 32, 0],
];

for (const [name, size, inset] of jobs) {
  await sharp(Buffer.from(svg(inset))).resize(size, size).png().toFile(path.join(out, name));
  console.log('готово:', name);
}
