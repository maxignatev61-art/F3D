// Подписанные ссылки на файлы (эскиз, модель, превью).
// Ссылка работает без входа, но только до своего срока и только на один файл,
// поэтому её можно вставлять в <img>, <model-viewer> и кнопку «Скачать»
// даже на фронтенде с другого адреса.
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { config } from './config.js';

const TTL_SEC = 24 * 60 * 60; // ссылка живёт сутки
const STEP_SEC = 60 * 60; // срок округляется до часа — так браузер кеширует файлы
let secret;

// Ключ подписи: из FILE_URL_SECRET или случайный, сохранённый в data/.
export async function initSigning() {
  if (process.env.FILE_URL_SECRET) {
    secret = Buffer.from(process.env.FILE_URL_SECRET);
    return;
  }
  const file = path.join(config.dataDir, 'file-url-secret');
  try {
    secret = await fs.readFile(file);
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    secret = randomBytes(32);
    await fs.writeFile(file, secret, { mode: 0o600 });
  }
}

const sign = (data) => createHmac('sha256', secret).update(data).digest('base64url');
const payload = (kind, name, exp, dl) => `${kind}/${name}|${exp}|${dl ? 1 : 0}`;

export function signedFileUrl(kind, name, { download = false } = {}) {
  if (!name) return null;
  const now = Math.floor(Date.now() / 1000);
  const exp = Math.ceil((now + TTL_SEC) / STEP_SEC) * STEP_SEC;
  const sig = sign(payload(kind, name, exp, download));
  return `/files/${kind}/${encodeURIComponent(name)}?exp=${exp}&${download ? 'dl=1&' : ''}sig=${sig}`;
}

export function verifyFileUrl(kind, name, query) {
  const exp = Number(query.exp);
  const sig = String(query.sig || '');
  if (!Number.isInteger(exp) || exp < Date.now() / 1000 || !sig) return false;
  const expected = Buffer.from(sign(payload(kind, name, exp, query.dl === '1')));
  const given = Buffer.from(sig);
  return given.length === expected.length && timingSafeEqual(given, expected);
}
