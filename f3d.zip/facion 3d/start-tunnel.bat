@echo off
rem Даёт серверу временный адрес https://....trycloudflare.com в интернете.
rem Сначала должен быть запущен сервер (start-server.bat).
rem Адрес появится ниже в рамке. Он меняется при каждом запуске.
chcp 65001 >nul
title Sketch3D tunnel
echo.
echo  Ищите ниже строку вида  https://....trycloudflare.com  - это адрес сервера.
echo  Окно не закрывайте: пока оно открыто, сайт друга видит сервер.
echo.
"D:\Programs\cloudflared\cloudflared.exe" tunnel --no-autoupdate --url http://localhost:3000
pause
