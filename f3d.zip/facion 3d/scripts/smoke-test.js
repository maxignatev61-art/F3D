// Проверка сервера в тестовом режиме (без трат кредитов).
// Сервер должен быть запущен с DEFAULT_PROVIDER=mock. Логин и пароль
// администратора берутся из ADMIN_LOGIN / ADMIN_PASSWORD (как в .env).
// Запуск: npm run smoke
import sharp from 'sharp';

const BASE = process.env.BASE_URL || 'http://localhost:3000';
const ADMIN = { login: process.env.ADMIN_LOGIN || 'admin', password: process.env.ADMIN_PASSWORD };
let passed = 0;

function check(condition, label, extra) {
  if (!condition) {
    console.error(`✗ ${label}`, extra === undefined ? '' : JSON.stringify(extra));
    process.exit(1);
  }
  passed++;
  console.log(`✓ ${label}`);
}

// Клиент со своей cookie — как отдельный браузер.
function client() {
  let cookie = '';
  const call = async (path, { json, ...options } = {}) => {
    const res = await fetch(BASE + path, {
      ...options,
      headers: { ...(cookie ? { Cookie: cookie } : {}), ...(json ? { 'Content-Type': 'application/json' } : {}) },
      body: json ? JSON.stringify(json) : options.body,
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0].endsWith('=') ? '' : set.split(';')[0];
    const type = res.headers.get('content-type') || '';
    const body = type.includes('json') ? await res.json() : await res.arrayBuffer();
    return { status: res.status, body, type, headers: res.headers };
  };
  call.login = (login, password) => call('/api/auth/login', { method: 'POST', json: { login, password } });
  return call;
}

const image = (w, h) => sharp({ create: { width: w, height: h, channels: 3, background: '#f4e1e6' } }).png().toBuffer();

function form(buffer, fileName, fields = {}) {
  const data = new FormData();
  data.append('image', new Blob([buffer], { type: 'image/png' }), fileName);
  for (const [k, v] of Object.entries(fields)) data.append(k, v);
  return data;
}

async function waitDone(call, id, limitSec = 120) {
  const started = Date.now();
  while (Date.now() - started < limitSec * 1000) {
    const { body } = await call(`/api/tasks/${id}`);
    if (!['queued', 'running'].includes(body.model.status)) return body.model;
    await new Promise((r) => setTimeout(r, 1000));
  }
  throw new Error('Генерация не закончилась вовремя');
}

if (!ADMIN.password) {
  console.error('Укажите ADMIN_PASSWORD (как в .env).');
  process.exit(1);
}

// ---------- Открытые адреса и файлы приложения ----------
const anon = client();
check((await anon('/api/health')).body.ok, 'health');
check((await anon('/api/config')).body.garmentTypes.length === 7, 'config без входа');
check((await anon('/manifest.webmanifest')).status === 200, 'manifest приложения');
check((await anon('/sw.js')).status === 200, 'service worker');
check((await anon('/icons/icon-192.png')).status === 200, 'иконка');
check((await anon('/admin/')).status === 200, 'страница администратора');

// ---------- Без входа ничего нельзя ----------
check((await anon('/api/models')).status === 401, 'галерея без входа → 401');
check((await anon('/api/generate', { method: 'POST', body: form(await image(600, 800), 'x.png') })).status === 401, 'генерация без входа → 401');
const wrong = await anon.login(ADMIN.login, 'wrong-password');
check(wrong.status === 401 && wrong.body.error.code === 'LOGIN_FAILED', 'неверный пароль → LOGIN_FAILED');

// ---------- Администратор заводит пользователей ----------
const admin = client();
const adminLogin = await admin.login(ADMIN.login, ADMIN.password);
check(adminLogin.status === 200 && adminLogin.body.user.role === 'admin', 'вход администратора', adminLogin.body);
check((await admin('/api/balance')).status === 200, 'баланс виден администратору');

const suffix = Date.now().toString(36);
const mashaLogin = `masha${suffix}`;
const created = await admin('/api/admin/users', { method: 'POST', json: { login: mashaLogin, name: 'Маша', dailyLimit: 2 } });
check(created.status === 201 && created.body.password.length >= 8, 'администратор создал пользователя', created.body);
const petya = await admin('/api/admin/users', { method: 'POST', json: { login: `petya${suffix}`, password: 'petya-pass-1' } });
check(petya.status === 201, 'второй пользователь с заданным паролем');
const dup = await admin('/api/admin/users', { method: 'POST', json: { login: mashaLogin } });
check(dup.status === 409 && dup.body.error.code === 'LOGIN_TAKEN', 'повторный логин → LOGIN_TAKEN');

// ---------- Пользователь работает со своей галереей ----------
const masha = client();
check((await masha.login(mashaLogin.toUpperCase(), created.body.password)).status === 200, 'вход пользователя (логин без учёта регистра)');
const me = await masha('/api/me');
check(me.body.user.remainingToday === 2, 'лимит виден пользователю', me.body);
check((await masha('/api/balance')).status === 403, 'баланс скрыт от пользователя');
check((await masha('/api/admin/users')).status === 403, 'админка закрыта для пользователя');

const noFile = await masha('/api/generate', { method: 'POST', body: new FormData() });
check(noFile.status === 400 && noFile.body.error.code === 'NO_FILE', 'без файла → NO_FILE');
const fake = new FormData();
fake.append('image', new Blob(['hello'], { type: 'image/png' }), 'fake.png');
const badFormat = await masha('/api/generate', { method: 'POST', body: fake });
check(badFormat.status === 400 && badFormat.body.error.code === 'INVALID_FORMAT', 'не картинка → INVALID_FORMAT');

const gen = await masha('/api/generate', {
  method: 'POST',
  body: form(await image(300, 400), 'Платье лето.png', { garmentType: 'dress', quality: 'high' }),
});
check(gen.status === 202 && gen.body.model.name === 'Платье лето', 'генерация принята, русское имя', gen.body);
check(gen.body.warnings.includes('SMALL_IMAGE'), 'предупреждение о маленькой картинке');
const id = gen.body.model.id;

const done = await waitDone(masha, id);
check(done.status === 'success', 'модель готова', done);
const glb = await masha(done.modelUrl);
check(glb.status === 200 && Buffer.from(glb.body).subarray(0, 4).toString('latin1') === 'glTF', 'GLB скачивается владельцем');
const dl = await masha(done.downloadUrl);
check(dl.status === 200 && (dl.headers.get('content-disposition') || '').includes('.glb'), 'скачивание с именем файла');

// ---------- Чужие модели не видны ----------
const petyaClient = client();
await petyaClient.login(`petya${suffix}`, 'petya-pass-1');
const plainModelPath = done.modelUrl.split('?')[0];
check((await petyaClient(`/api/tasks/${id}`)).status === 404, 'чужая модель → 404');
check((await petyaClient(plainModelPath)).status === 404, 'чужой файл без подписи → 404');
check((await anon(plainModelPath)).status === 401, 'файл без подписи и без входа → 401');
check(!(await petyaClient('/api/models')).body.models.some((m) => m.id === id), 'в чужой галерее модели нет');

// ---------- Фронтенд на другом адресе: токен и подписанные ссылки ----------
const cfg = (await anon('/api/config')).body;
check(cfg.limits?.maxFileSizeBytes === 10 * 1024 * 1024 && cfg.limits.minImageSide === 512, 'config.limits для фронтенда');
check(cfg.garmentTypes.some((t) => t.value === 't-shirt') && cfg.garmentTypes.some((t) => t.value === 'trousers'), 'типы t-shirt и trousers');

const tokenLogin = await anon.login(`petya${suffix}`, 'petya-pass-1');
check(typeof tokenLogin.body.token === 'string' && tokenLogin.body.token.length > 20, 'вход возвращает токен');
const bearer = (path, options = {}) =>
  fetch(BASE + path, { ...options, headers: { Authorization: `Bearer ${tokenLogin.body.token}`, ...(options.headers || {}) } });
const bearerMe = await bearer('/api/me');
check(bearerMe.status === 200 && (await bearerMe.json()).user.login === `petya${suffix}`, 'запрос с токеном в заголовке');

const viaToken = await bearer('/api/generate', {
  method: 'POST',
  body: form(await image(600, 800), 'trousers.png', { garmentType: 'pants', provider: 'meshy' }),
});
const viaTokenBody = await viaToken.json();
check(viaToken.status === 202 && viaTokenBody.model.garmentType === 'trousers', 'старое название pants → trousers', viaTokenBody);
check(viaTokenBody.model.provider !== 'meshy', 'выбор сервиса от пользователя игнорируется');
const tokenDone = await waitDone(async (p) => ({ body: await (await bearer(p)).json() }), viaTokenBody.model.id);
check(tokenDone.status === 'success', 'генерация с токеном готова');

const signedGlb = await fetch(BASE + tokenDone.modelUrl, { headers: { Origin: 'https://threadly-gamma-nine.vercel.app' } });
check(signedGlb.status === 200 && signedGlb.headers.get('access-control-allow-origin'), 'модель по подписанной ссылке без входа, с CORS');
const signedDl = await fetch(BASE + tokenDone.downloadUrl);
check(signedDl.status === 200 && (signedDl.headers.get('content-disposition') || '').includes('.glb'), 'скачивание по подписанной ссылке');
check((await fetch(BASE + tokenDone.modelUrl.replace(/sig=.{4}/, 'sig=AAAA'))).status === 401, 'поддельная подпись → 401');
check((await fetch(BASE + tokenDone.sketchUrl)).status === 200, 'эскиз по подписанной ссылке');
const filtered = await (await bearer('/api/models?type=trousers')).json();
check(filtered.models.length === 1, 'фильтр галереи по trousers');
check((await bearer(`/api/models/${viaTokenBody.model.id}`, { method: 'DELETE' })).status === 204, 'удаление с токеном');
check((await bearer('/api/auth/logout', { method: 'POST' })).status === 204, 'выход по токену');
check((await bearer('/api/me')).status === 401, 'после выхода токен не работает');

const cors = await fetch(BASE + '/api/models', {
  method: 'OPTIONS',
  headers: { Origin: 'https://threadly-gamma-nine.vercel.app', 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'authorization' },
});
check(cors.headers.get('access-control-allow-origin') === 'https://threadly-gamma-nine.vercel.app', 'CORS для фронтенда на Vercel');
const evil = await fetch(BASE + '/api/models', { method: 'OPTIONS', headers: { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'GET' } });
check(!evil.headers.get('access-control-allow-origin'), 'чужой сайт не получает доступ к API');

// ---------- Переименование, «создать заново», лимит ----------
const renamed = await masha(`/api/models/${id}`, { method: 'PATCH', json: { name: 'Новое имя' } });
check(renamed.body.model?.name === 'Новое имя', 'переименование');
const again = await masha(`/api/models/${id}/regenerate`, { method: 'POST', json: {} });
check(again.status === 202 && again.body.model.id !== id, 'создать заново');
const over = await masha('/api/generate', { method: 'POST', body: form(await image(600, 800), 'third.png') });
check(over.status === 429 && over.body.error.code === 'LIMIT_REACHED', 'третья генерация при лимите 2 → LIMIT_REACHED', over.body);

// ---------- Ошибка генерации (в имени файла «fail») ----------
const failing = await admin('/api/generate', { method: 'POST', body: form(await image(800, 800), 'test-fail.png') });
const failed = await waitDone(admin, failing.body.model.id);
check(failed.status === 'failed' && failed.error.code === 'GENERATION_FAILED', 'ошибка генерации доходит до фронтенда');

// ---------- Управление доступом ----------
const mashaId = created.body.user.id;
const reset = await admin(`/api/admin/users/${mashaId}`, { method: 'PATCH', json: { resetPassword: true } });
check(reset.status === 200 && reset.body.password, 'сброс пароля');
check((await masha('/api/me')).status === 401, 'после сброса пароля старый вход закрыт');
check((await masha.login(mashaLogin, reset.body.password)).status === 200, 'вход с новым паролем');

const change = await masha('/api/me/password', { method: 'POST', json: { currentPassword: reset.body.password, newPassword: 'masha-own-pass' } });
check(change.status === 200 && change.body.token, 'пользователь сменил пароль сам и получил новый токен');
check((await masha('/api/me')).status === 200, 'после смены пароля вход сохранился');

const disable = await admin(`/api/admin/users/${petya.body.user.id}`, { method: 'PATCH', json: { disabled: true } });
check(disable.status === 200 && disable.body.user.disabled, 'отключение пользователя');
check((await petyaClient('/api/me')).status === 401, 'отключённый пользователь сразу выходит');

const selfDisable = await admin(`/api/admin/users/${adminLogin.body.user.id}`, { method: 'PATCH', json: { disabled: true } });
check(selfDisable.status === 400, 'нельзя отключить самого себя');

// ---------- Защита от подбора пароля ----------
const brute = client();
let last;
for (let i = 0; i < 6; i++) last = await brute.login(`nobody${suffix}`, 'x');
check(last.status === 429 && last.body.error.code === 'TOO_MANY_ATTEMPTS', 'подбор пароля блокируется');

// ---------- Удаление и выход ----------
for (const [c, m] of [[masha, id], [masha, again.body.model.id], [admin, failing.body.model.id]]) {
  check((await c(`/api/models/${m}`, { method: 'DELETE' })).status === 204, `удаление ${m.slice(0, 8)}`);
}
check((await masha(done.modelUrl)).status === 404, 'файлы удалённой модели удалены');
check((await masha('/api/auth/logout', { method: 'POST' })).status === 204, 'выход');
check((await masha('/api/models')).status === 401, 'после выхода → 401');

console.log(`\nВсе проверки пройдены: ${passed}`);
