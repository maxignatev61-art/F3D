// Service worker приложения «Эскиз → 3D».
// Запоминает страницы и файлы интерфейса, чтобы приложение открывалось
// даже при плохой связи. Данные (API, модели) всегда берутся из сети.
const CACHE = 'sketch3d-v1';
const SKIP = ['/api/', '/files/', '/admin', '/dev'];

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE).then((cache) => cache.put(request, copy));
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;
    if (request.mode === 'navigate') {
      const shell = await caches.match('/');
      if (shell) return shell;
    }
    return Response.error();
  }
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (SKIP.some((prefix) => url.pathname.startsWith(prefix))) return;
  event.respondWith(networkFirst(request));
});
