// Meshy API: https://docs.meshy.ai/api/image-to-3d
// Картинка передаётся сразу в задании (data URI), отдельной загрузки нет.
import { config } from '../config.js';
import { AppError, errorInfo } from '../errors.js';

const cfg = config.meshy;

function mapError(httpStatus, body) {
  const details = body?.message || `HTTP ${httpStatus}`;
  if (httpStatus === 401) return new AppError('INVALID_API_KEY', 503, details);
  if (httpStatus === 402) return new AppError('NO_CREDITS', 402, details);
  if (httpStatus === 429) return new AppError('RATE_LIMITED', 429, details);
  if (httpStatus >= 500) return new AppError('PROVIDER_UNAVAILABLE', 502, details);
  return new AppError('GENERATION_FAILED', 502, `Meshy ${httpStatus}: ${details}`);
}

async function call(method, pathname, json) {
  let res;
  try {
    res = await fetch(cfg.baseUrl + pathname, {
      method,
      headers: {
        Authorization: `Bearer ${cfg.apiKey}`,
        ...(json ? { 'Content-Type': 'application/json' } : {}),
      },
      body: json ? JSON.stringify(json) : undefined,
      signal: AbortSignal.timeout(90_000),
    });
  } catch (err) {
    throw new AppError('PROVIDER_UNAVAILABLE', 502, err.cause?.message || err.message);
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    // Пустой или не-JSON ответ.
  }
  if (!res.ok) throw mapError(res.status, body);
  return body;
}

// Режим 2k доступен только у новых моделей Meshy.
const supportsUltra = () => ['latest', 'meshy-7.1'].includes(cfg.aiModel);

export const meshy = {
  id: 'meshy',
  name: 'Meshy',
  acceptedFormats: ['jpeg', 'png', 'webp'],
  configured: () => Boolean(cfg.apiKey),

  async createTask({ image, texture, quality }) {
    const body = {
      image_url: `data:${image.mime};base64,${image.buffer.toString('base64')}`,
      ai_model: cfg.aiModel,
      should_texture: texture,
      enable_pbr: texture,
      target_formats: ['glb'],
    };
    if (quality === 'high' && supportsUltra()) body.geometry_resolution = '2k';
    const { result } = await call('POST', '/image-to-3d', body);
    return result;
  },

  async getTask(taskId) {
    const t = await call('GET', `/image-to-3d/${encodeURIComponent(taskId)}`);
    const base = {
      progress: Number(t.progress) || 0,
      credits: t.consumed_credits ?? null,
    };
    switch (t.status) {
      case 'PENDING':
        return { ...base, status: 'queued' };
      case 'IN_PROGRESS':
        return { ...base, status: 'running' };
      case 'SUCCEEDED':
        return {
          ...base,
          status: 'success',
          modelUrl: t.model_urls?.glb,
          previewUrl: t.thumbnail_url,
        };
      case 'FAILED':
      case 'CANCELED':
        return {
          ...base,
          status: 'failed',
          error: errorInfo('GENERATION_FAILED', `Meshy: ${t.status} ${t.task_error?.message ?? ''}`.trim()),
        };
      default:
        return { ...base, status: 'running' };
    }
  },

  async getBalance() {
    const d = await call('GET', '/balance');
    return { balance: Number(d.balance), frozen: 0 };
  },
};
